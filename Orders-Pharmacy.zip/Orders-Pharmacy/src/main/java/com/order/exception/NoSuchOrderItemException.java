package com.order.exception;

public class NoSuchOrderItemException extends Exception{
	public NoSuchOrderItemException(String msg)
	{
		super(msg);
	}

}
