package com.order.exception;

public class InvalidOrderException extends Exception {

	public InvalidOrderException(String msg)
	{
		super(msg);
	}
}
