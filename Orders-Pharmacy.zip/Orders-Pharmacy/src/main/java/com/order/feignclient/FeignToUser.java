package com.order.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.order.entities.User;

@FeignClient(name="ADMIN-DOCTOR-PHARMACY")
public interface FeignToUser {

	@GetMapping("/user/{userid}")
	public User getUserById(@PathVariable int userid);
	
	@GetMapping("/user/jwt-secret")
	public String getSecretKeyFromUser();
	
	@GetMapping("/user/viewuser/{username}")
	public User getUserByUserName(@PathVariable String username);
}
