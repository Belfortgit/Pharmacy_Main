package com.order.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.order.entities.OrderException;
import com.order.exception.InvalidOrderException;
import com.order.exception.NoSuchOrderItemException;

@ControllerAdvice
@RestControllerAdvice
public class OrderItemsControllerAdvice {

    private Logger logger = LoggerFactory.getLogger(OrderItemsControllerAdvice.class);

    @ExceptionHandler(NoSuchOrderItemException.class)
    public ResponseEntity<Object> handlenosuch(NoSuchOrderItemException ex) {
    	
        logger.error("NoSuchOrderItemException occurred: {}", ex.getMessage());
        OrderException obj = new OrderException(ex.getMessage(), "Enter a valid Item Id", "NoSuchOrderItemException");
        return new ResponseEntity<>(obj, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(InvalidOrderException.class)
    public ResponseEntity<Object> handleinvalid(InvalidOrderException ex) {
    	
        logger.error("InvalidOrderException occurred: {}", ex.getMessage());
        OrderException obj = new OrderException(ex.getMessage(), "Enter a valid Order Id", "InvalidOrderException");
        return new ResponseEntity<>(obj, HttpStatus.BAD_REQUEST);
    }
    
}