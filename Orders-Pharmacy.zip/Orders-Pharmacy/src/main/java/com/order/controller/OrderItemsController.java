package com.order.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.entities.OrderItems;
import com.order.exception.NoSuchOrderItemException;
import com.order.service.OrderItemsService;

@RestController
@RequestMapping("/orderitems")
public class OrderItemsController {
	
	@Autowired
	private OrderItemsService service;
	
	@PostMapping("/add")
	public OrderItems add(@RequestBody OrderItems item)
	{
		return service.add(item);
	}
	
	@GetMapping("/view")
	public List<OrderItems> get()
	{
		return service.get();
	}
	
	@DeleteMapping("/delete/{orderitemid}")
	public String delete(@PathVariable int orderitemid) throws NoSuchOrderItemException
	{
		Optional<OrderItems> item = service.getById(orderitemid);
		return service.deleteItem(orderitemid);
	}
	
	@GetMapping("/{id}")
	public OrderItems getbyId(@PathVariable int id) throws NoSuchOrderItemException
	{
		
		Optional<OrderItems> item = service.getById(id);
		return service.getById(id).get();
	}
}
