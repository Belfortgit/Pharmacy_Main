package com.order.controller;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.entities.OrderItems;
import com.order.entities.Orders;
import com.order.entities.Payment;
import com.order.entities.User;
import com.order.exception.InvalidOrderException;
import com.order.exception.NoSuchOrderItemException;
import com.order.feignclient.FeignToUser;
import com.order.service.OrderItemsService;
import com.order.service.OrderService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	private OrderService service;
	
	@Autowired
	private OrderItemsService itemservice;

	
	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @GetMapping("/view")
    public List<Orders> getOrders() {

        return service.getAllOrders();
    }
	
	@GetMapping("/{orderid}")
	public Orders getbyid(@PathVariable int orderid) throws InvalidOrderException
	{
		return service.getOrderById(orderid);
	}
	
	@PostMapping("/add")
	public Orders add(@RequestBody Orders order) throws InvalidOrderException
	{		
		return service.add(order);
	}
	
	@DeleteMapping("/delete/{orderid}")
	public String deleteorder(@PathVariable int orderid) throws InvalidOrderException
	{
		return service.deleteOrder(orderid);
	}
	
	@PutMapping("/{orderId}/{status}")
	public Orders update(@RequestBody User user, @PathVariable int orderId,@PathVariable String status) throws NoSuchOrderItemException, InvalidOrderException
	{
		OrderItems obj = itemservice.getByOrderId(orderId).get();
		Orders order = new Orders(orderId,obj.getDrugName(),user.getUserId(),user.getUserName(),
				LocalDate.now(),status,obj.getPrice());
		
		return add(order);		
	}
	
	
}
