package com.order.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entities.OrderItems;
import com.order.exception.NoSuchOrderItemException;
import com.order.repository.OrderItemsRepository;
import com.order.service.OrderItemsService;

@Service
public class OrderItemsServiceImpl  implements OrderItemsService{
	
	private Logger logger = LoggerFactory.getLogger(OrderItemsServiceImpl.class);

	@Autowired
	private OrderItemsRepository repo;
	
	@Override
	public OrderItems add(OrderItems item) {
		logger.info("Adding new order item: {}", item);
		OrderItems savedItem = repo.save(item);
		logger.info("Order item added successfully with id: {}", savedItem.getId());
		return savedItem;
	}

	@Override
	public List<OrderItems> get() {
		logger.info("Fetching all order items.");
		List<OrderItems> items = repo.findAll();
		logger.info("Retrieved {} order items.", items.size());
		return items;
	}

	@Override
	public Optional<OrderItems> getById(int id) throws NoSuchOrderItemException {
		
		logger.info("Fetching order item with id: {}", id);
		Optional<OrderItems> item = repo.findById(id);
		if(!item.isPresent())
		{
			logger.warn("Order item with id {} not found.",id);
			throw new NoSuchOrderItemException("No such element with id "+id);
		}
		logger.info("Order item with id {} found.", id);
		return item;
	}

	@Override
	public String deleteItem(int id) throws NoSuchOrderItemException {
		
		logger.info("Deleting order item with id: {}", id);
		Optional<OrderItems> item = repo.findById(id);
		if(!item.isPresent())
		{
			logger.warn("Order item with id {} not found, cannot delete.",id);
			throw new NoSuchOrderItemException("No such element with id "+id);
		}
		repo.deleteById(id);
		logger.info("Order item with id {} deleted successfully.", id);
		return "Deleted order item of id= "+id;
	}

	@Override
	public Optional<OrderItems> getByOrderId(int orderid) throws NoSuchOrderItemException 
	{
		logger.info("Fetching order item with order id: {}", orderid);
		System.out.println("step2.1");
		Optional<OrderItems> item = repo.getOrderByOrderId(orderid);
		System.out.println("step2.2");
		if(!item.isPresent())
		{
			System.out.println("step2.2 Exception");
			logger.warn("Order item with order id {} not found.",orderid);
			throw new NoSuchOrderItemException("No such element with order id "+orderid);
		}
		logger.info("Order item with order id {} found.", orderid);
		return item;
		
		
	}
//	
//	@Override
//	public Optional<OrderItems> getById(int id) throws NoSuchOrderItemException {
//		
//		logger.info("Fetching order item with id: {}", id);
//		Optional<OrderItems> item = repo.findById(id);
//		if(!item.isPresent())
//		{
//			logger.warn("Order item with id {} not found.",id);
//			throw new NoSuchOrderItemException("No such element with id "+id);
//		}
//		logger.info("Order item with id {} found.", id);
//		return item;
//	}

}