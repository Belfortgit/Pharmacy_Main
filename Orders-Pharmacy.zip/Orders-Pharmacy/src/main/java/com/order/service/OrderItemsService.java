package com.order.service;

import java.util.List;
import java.util.Optional;

import com.order.entities.OrderItems;
import com.order.exception.NoSuchOrderItemException;

public interface OrderItemsService {

	OrderItems add(OrderItems item);
	List<OrderItems> get();
	String deleteItem(int id) throws NoSuchOrderItemException;
	Optional<OrderItems> getById(int id) throws NoSuchOrderItemException;
	Optional<OrderItems> getByOrderId(int orderid) throws NoSuchOrderItemException;
}
