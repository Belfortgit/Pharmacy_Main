package com.order.service;

import java.util.List;
import java.util.Optional;

import com.order.entities.Orders;
import com.order.entities.Payment;
import com.order.exception.InvalidOrderException;

public interface OrderService {

	List<Orders> getAllOrders();
	Orders add(Orders order) throws InvalidOrderException;
	Orders getOrderById(int orderId) throws InvalidOrderException;
	String deleteOrder(int orderid) throws InvalidOrderException;
	Orders changeStatusById(int orderId, String status) throws InvalidOrderException;
	
//	List<Orders> getVerifiedStatus();
	
//	//Adding Payment
//	void addVerifiedPayments(Orders order);
//	List<Payment> getPaymentByUserId(int userid);
//	void deletePayment(Orders order);
}
