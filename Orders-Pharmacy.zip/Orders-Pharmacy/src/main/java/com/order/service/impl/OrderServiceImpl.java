package com.order.service.impl;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entities.Orders;
import com.order.entities.Payment;
import com.order.exception.InvalidOrderException;
import com.order.repository.OrderRepository;
import com.order.repository.PaymentRepository;
import com.order.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService{

	private Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

	//Verifying the status
	public boolean verifyStatus(String str)
	{
		Set<String> statusMap = new HashSet();
		statusMap.add("PLACED");
		statusMap.add("VERIFIED");
		statusMap.add("PICKED_UP");
		statusMap.add("CANCELLED");
		statusMap.add("OUT_OF_STOCK");
		
		return statusMap.contains(str);

	}

	@Autowired
	private OrderRepository repo;
	
	@Autowired
	private PaymentRepository paymentRepo;
	
	@Override
	public List<Orders> getAllOrders() {
		logger.info("Fetching all orders.");
		List<Orders> orders = repo.findAll();
		logger.info("Retrieved {} orders.", orders.size());
		return orders;
	}

	@Override
	public Orders add(Orders order) throws InvalidOrderException {
		String status = order.getStatus().toUpperCase();
		logger.info("Adding order with status: {}", status);
		if(verifyStatus(status))
		{
			order.setStatus(status);
			Orders savedOrder = repo.save(order);
			logger.info("Order added successfully with id: {}", savedOrder.getOrderId());
			return savedOrder;
		}
		else {
			logger.warn("Invalid order status provided: {}", status);
			throw new InvalidOrderException("The order status is invalid {'PLACED','VERIFIED',"
					+ "'PICKED_UP','CANCELLED','OUT_OF_STOCK'}");
		}
	}

	@Override
	public Orders getOrderById(int orderId) throws InvalidOrderException {
		
		logger.info("Fetching order with id: {}", orderId);
		Optional<Orders> order = repo.findById(orderId);
		if(order.isPresent())
		{
			logger.info("Order with id {} found.", orderId);
			return order.get();
		} 
		else 
		{
			logger.warn("Order with id {} not found.", orderId);
			throw new InvalidOrderException("The Order Id is Invalid");
		}
	}

	@Override
	public String deleteOrder(int orderid) throws InvalidOrderException {
		
		logger.info("Deleting order with id: {}", orderid);
		Optional<Orders> obj = repo.findById(orderid);
		if(obj.isPresent())
		{
			repo.deleteById(orderid);
			logger.info("Order with id {} deleted successfully.", orderid);
			return "Successfully deleted order of id= "+orderid;
		}
		else {
			logger.warn("Order with id {} not found, cannot delete.", orderid);
			throw new InvalidOrderException("The order status is invalid {'PLACED','VERIFIED',"
					+ "'PICKED_UP','CANCELLED','OUT_OF-STOCK'}");
		}
	}
	
	public Orders changeStatusById(int orderid, String status) throws InvalidOrderException
	{
		status = status.toUpperCase();
		logger.info("Changing status of order id {} to {}", orderid, status);
		if(verifyStatus(status))
		{
			Optional<Orders> obj = repo.findById(orderid);
			if(obj.isPresent())
			{
				obj.get().setStatus(status);
				Orders updatedOrder = repo.save(obj.get());
				logger.info("Order status changed successfully. Order Id: {}, New Status: {}", orderid, status);
				return updatedOrder;
			}
			else {
				logger.warn("Order with id {} not found, cannot change status.", orderid);
				throw new InvalidOrderException("The Order Id is Invalid");
			}
		}
		else {
			logger.warn("Invalid order status provided: {}", status);
			throw new InvalidOrderException("The order status is invalid {'PLACED','VERIFIED',"
					+ "'PICKED_UP','CANCELLED','OUT_OF-STOCK'}");
		}
	}
}