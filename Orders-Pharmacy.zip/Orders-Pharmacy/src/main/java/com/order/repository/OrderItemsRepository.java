package com.order.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.order.entities.OrderItems;

public interface OrderItemsRepository extends JpaRepository<OrderItems, Integer>{
	@Query(value="select * from order_items where order_id = :orderid", nativeQuery=true)
	Optional<OrderItems> getOrderByOrderId(int orderid);
}
