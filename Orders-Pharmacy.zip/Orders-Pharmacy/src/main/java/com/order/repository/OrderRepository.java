package com.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.order.entities.OrderItems;
import com.order.entities.Orders;

public interface OrderRepository extends JpaRepository<Orders,Integer> {

}
