package com.order.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.order.entities.Payment;

public interface PaymentRepository extends JpaRepository<Payment, String> {

	@Query(value="select * from payment where payment_id like :Pid", nativeQuery=true)
	Optional<Payment> getByPid(String Pid);
	
	@Query(value="select * from payment where user_id = :userid", nativeQuery=true)
	List<Payment> getPaymentByUserId(int userid);
}
