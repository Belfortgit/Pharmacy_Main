package com.order;

import com.order.controller.OrderController;
import com.order.entities.OrderItems;
import com.order.entities.Orders;
import com.order.entities.Payment;
import com.order.entities.User;
import com.order.exception.InvalidOrderException;
import com.order.exception.NoSuchOrderItemException;
import com.order.feignclient.FeignToUser;
import com.order.service.OrderItemsService;
import com.order.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrderControllerTest {

    @Mock
    private OrderService service;

    @Mock
    private OrderItemsService itemservice;

    @Mock
    private FeignToUser feignuser;

    @InjectMocks
    private OrderController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

//    @Test
//    void get_shouldReturnListOfOrders() {
//        List<Orders> orders = Arrays.asList(new Orders(), new Orders());
//        when(service.getAllOrders()).thenReturn(orders);
//
//        List<Orders> result = controller.get();
//
//        assertEquals(orders, result);
//        verify(service, times(1)).getAllOrders();
//    }

    @Test
    void getbyid_shouldReturnOrderById() throws InvalidOrderException {
        int orderId = 1;
        Orders order = new Orders();
        when(service.getOrderById(orderId)).thenReturn(order);

        Orders result = controller.getbyid(orderId);

        assertEquals(order, result);
        verify(service, times(1)).getOrderById(orderId);
    }

    @Test
    void getbyid_shouldThrowInvalidOrderException() throws InvalidOrderException {
        int orderId = 1;
        when(service.getOrderById(orderId)).thenThrow(new InvalidOrderException("Order not found"));

        assertThrows(InvalidOrderException.class, () -> controller.getbyid(orderId));
        verify(service, times(1)).getOrderById(orderId);
    }

//    @Test
//    void getpayment_shouldReturnListOfPayments() throws InvalidOrderException {
//        int userId = 1;
//        List<Payment> payments = Arrays.asList(new Payment(), new Payment());
//        when(service.getPaymentByUserId(userId)).thenReturn(payments);
//
//        List<Payment> result = controller.getpayment(userId);
//
//        assertEquals(payments, result);
//        verify(service, times(1)).getPaymentByUserId(userId);
//    }
//
//    @Test
//    void getpayment_shouldThrowInvalidOrderException_payment() throws InvalidOrderException {
//        int userId = 1;
//        when(service.getPaymentByUserId(userId)).thenThrow(new InvalidOrderException("payment not found"));
//
//        assertThrows(InvalidOrderException.class, () -> controller.getpayment(userId));
//        verify(service, times(1)).getPaymentByUserId(userId);
//    }

//    @Test
//    void add_shouldAddOrder() throws InvalidOrderException {
//        Orders order = new Orders();
//        when(service.add(order)).thenReturn(order);
//
//        Orders result = controller.add(order);
//
//        assertEquals(order, result);
//        verify(service, times(1)).add(order);
//        verify(service, times(1)).addVerifiedPayments(order);
//    }
//
//    @Test
//    void add_shouldThrowInvalidOrderExceptionOnAdd() throws InvalidOrderException {
//        Orders order = new Orders();
//        when(service.add(order)).thenThrow(new InvalidOrderException("Invalid Order"));
//
//        assertThrows(InvalidOrderException.class, () -> controller.add(order));
//        verify(service, times(1)).addVerifiedPayments(order);
//        verify(service, times(1)).add(order);
//    }

    @Test
    void deleteorder_shouldDeleteOrder() throws InvalidOrderException {
        int orderId = 1;
        when(service.deleteOrder(orderId)).thenReturn("Order deleted");

        String result = controller.deleteorder(orderId);

        assertEquals("Order deleted", result);
        verify(service, times(1)).deleteOrder(orderId);
    }

    @Test
    void deleteorder_shouldThrowInvalidOrderException_delete() throws InvalidOrderException {
        int orderId = 1;
        when(service.deleteOrder(orderId)).thenThrow(new InvalidOrderException("Order not found"));

        assertThrows(InvalidOrderException.class, () -> controller.deleteorder(orderId));
        verify(service, times(1)).deleteOrder(orderId);
    }

//    @Test
//    void update_shouldUpdateOrder() throws NoSuchOrderItemException, InvalidOrderException {
//        int userId = 1;
//        int orderId = 1;
//        String status = "Shipped";
//        OrderItems orderItems = new OrderItems();
//        orderItems.setDrugName("DrugA");
//        orderItems.setPrice(100.0);
//        when(itemservice.getByOrderId(orderId)).thenReturn(Optional.of(orderItems));
//        User user = new User();
//        user.setUserId(userId);
//        user.setUserName("TestUser");
//        when(feignuser.getUserById(userId)).thenReturn(user);
//        Orders expectedOrder = new Orders(orderId, "DrugA", userId, "TestUser", LocalDate.now(), status, 100.0);
//        when(service.add(any(Orders.class))).thenReturn(expectedOrder);
//
//        Orders result = controller.update(userId, orderId, status);
//
//        assertEquals(expectedOrder, result);
//        verify(itemservice, times(1)).getByOrderId(orderId);
//        verify(feignuser, times(1)).getUserById(userId);
//        verify(service, times(1)).addVerifiedPayments(any(Orders.class));
//        verify(service, times(1)).add(any(Orders.class));
//    }
//
//    @Test
//    void update_shouldThrowNoSuchOrderItemException() throws NoSuchOrderItemException, InvalidOrderException {
//        int userId = 1;
//        int orderId = 1;
//        String status = "Shipped";
//        when(itemservice.getByOrderId(orderId)).thenReturn(Optional.empty());
//
//        assertThrows(NoSuchOrderItemException.class, () -> controller.update(userId, orderId, status));
//        verify(itemservice, times(1)).getByOrderId(orderId);
//    }

//    @Test
//    void update_shouldThrowInvalidOrderException_update() throws NoSuchOrderItemException, InvalidOrderException {
//        int userId = 1;
//        int orderId = 1;
//        String status = "Shipped";
//        OrderItems orderItems = new OrderItems();
//        orderItems.setDrugName("DrugA");
//        orderItems.setPrice(100.0);
//        when(itemservice.getByOrderId(orderId)).thenReturn(Optional.of(orderItems));
//        User user = new User();
//        user.setUserId(userId);
//        user.setUserName("TestUser");
//        when(feignuser.getUserById(userId)).thenReturn(user);
//        when(service.add(any(Orders.class))).thenThrow(new InvalidOrderException("Invalid Order"));
//
//        assertThrows(InvalidOrderException.class, () -> controller.update(userId, orderId, status));
//        verify(itemservice, times(1)).getByOrderId(orderId);
//        verify(feignuser, times(1)).getUserById(userId);
//        verify(service, times(1)).addVerifiedPayments(any(Orders.class));
//        verify(service, times(1)).add(any(Orders.class));
//    }
}