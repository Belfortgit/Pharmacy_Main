package com.order;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.order.entities.OrderItems;
import com.order.entities.Orders;
import com.order.exception.InvalidOrderException;
import com.order.exception.NoSuchOrderItemException;
import com.order.service.OrderItemsService;
import com.order.service.OrderService;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class OrdersPharmacyApplicationTests {

	@Mock
	OrderService orderService;
	
	@Mock
	OrderItemsService itemService;
	
	//ORDERS
	@Test
	void testOrderforGetAll() 
	{
		LocalDate orderDate = LocalDate.of(2023, 11, 11);
        Orders order = new Orders(1,"", 1,"", orderDate, "status", 23);
        
        List<Orders> orderList = new ArrayList<>();
        orderList.add(order);
        
		when(orderService.getAllOrders()).thenReturn(orderList);
		
		assertSame(orderService.getAllOrders(), orderList);
	}
	
	@Test
	void testOrderforAddOrder() throws InvalidOrderException
	{
		LocalDate orderDate = LocalDate.of(2023, 11, 11);
		Orders order = new Orders(1,"", 1,"", orderDate, "status", 23);
		Orders order2 = new Orders(2,"", 2,"", orderDate, "status", 23);
		
		when(orderService.add(order)).thenReturn(order);
		when(orderService.add(order2)).thenThrow(new InvalidOrderException(null));
		
		assertSame(orderService.add(order),order);
		assertThrows(InvalidOrderException.class,() ->{
			orderService.add(order2);
		});
	}
	
	@Test
	void testOrderforGetOrderById() throws InvalidOrderException
	{
		LocalDate orderDate = LocalDate.of(2023, 11, 11);
		Orders order =new Orders(1,"", 1,"", orderDate, "status", 23);
		
		when(orderService.getOrderById(1)).thenReturn(order);
		
		assertSame(orderService.getOrderById(1),order);
	}
	
	@Test
	void testOrderforGetOrderByIdThrowException() throws InvalidOrderException
	{
		when(orderService.getOrderById(2000)).thenThrow(new InvalidOrderException(null));
		
		assertThrows(InvalidOrderException.class,() ->{
			orderService.getOrderById(2000);
		});
	}
	
	@Test
	void testOrderforDeleteOrder() throws InvalidOrderException
	{	
		when(orderService.deleteOrder(1)).thenReturn("Deleted");
		
		assertEquals(orderService.deleteOrder(1),"Deleted");
	}
	
	@Test
	void testOrderforDeleteOrderThrowsException() throws InvalidOrderException
	{	
		when(orderService.deleteOrder(1)).thenThrow(new InvalidOrderException(null));
		
		assertThrows(InvalidOrderException.class,() ->{
			orderService.deleteOrder(1);
		});
	}
	
	@Test
	void testOrderforChangingtheStatus() throws InvalidOrderException
	{
		LocalDate orderDate = LocalDate.of(2023, 11, 11);
		Orders order = new Orders(1,"", 1,"", orderDate, "status", 23);
		when(orderService.changeStatusById(1, "placed")).thenReturn(order);
		when(orderService.changeStatusById(1, "pled")).thenThrow(new InvalidOrderException(null));
		
		assertSame(orderService.changeStatusById(1, "placed"),order);
		
		assertThrows(InvalidOrderException.class,() ->{
			orderService.changeStatusById(1, "pled");
		});
	}
	
	//ORDER-ITEMS
	
	@Test
	void testOrderItemsforGet()
	{
		List<OrderItems> itemList = new ArrayList();
		itemList.add(new OrderItems(1, 1, 1, 12, 23,"drugname"));
		when(itemService.get()).thenReturn(itemList);
		
		assertSame(itemService.get(),itemList);
	}
	
	@Test
	void testOrderItemsforAdd()
	{
		List<OrderItems> itemList = new ArrayList();
		OrderItems item = new OrderItems(1, 1, 1, 12, 23,"drugname");
		
		itemList.add(item);
		when(itemService.add(item)).thenReturn(item);
		
		assertSame(itemService.add(item),item);
	}
	
	void testOrderItemsforGetById() throws NoSuchOrderItemException
	{
		OrderItems item = new OrderItems(1, 1, 1, 12, 23,"drugname");

		when(itemService.getById(1).get()).thenReturn(item);	
		when(itemService.getById(1).get()).thenThrow(new NoSuchOrderItemException(null));
		
		assertSame(itemService.getById(1),item);
		assertThrows(NoSuchOrderItemException.class,() ->{
			itemService.getById(1).get();
		});
	}
	
	@Test
	void testOrderItemsforDelete() throws NoSuchOrderItemException
	{		
		when(itemService.deleteItem(1)).thenReturn("Deleted order item of id");
		
		assertEquals(itemService.deleteItem(1),"Deleted order item of id");
	}
	
	@Test
	void testOrderItemsforDeleteThrowsException() throws NoSuchOrderItemException
	{		
		when(itemService.deleteItem(1)).thenThrow(new NoSuchOrderItemException(null));
		
		assertThrows(NoSuchOrderItemException.class,() ->{
			itemService.deleteItem(1);
		});
	}

}
