package com.order;

import com.order.controller.OrderItemsController;
import com.order.entities.OrderItems;
import com.order.exception.NoSuchOrderItemException;
import com.order.service.OrderItemsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class OrderItemsControllerTest {

    @Mock
    private OrderItemsService service;

    @InjectMocks
    private OrderItemsController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void add_shouldAddOrderItem() {
        OrderItems item = new OrderItems();
        when(service.add(item)).thenReturn(item);

        OrderItems result = controller.add(item);

        assertEquals(item, result);
        verify(service, times(1)).add(item);
    }

    @Test
    void get_shouldReturnListOfOrderItems() {
        List<OrderItems> items = Arrays.asList(new OrderItems(), new OrderItems());
        when(service.get()).thenReturn(items);

        List<OrderItems> result = controller.get();

        assertEquals(items, result);
        verify(service, times(1)).get();
    }

    @Test
    void delete_shouldDeleteItem() throws NoSuchOrderItemException {
        int orderItemId = 1;
        OrderItems item = new OrderItems();
        when(service.getById(orderItemId)).thenReturn(Optional.of(item));
        when(service.deleteItem(orderItemId)).thenReturn("Item deleted");

        String result = controller.delete(orderItemId);

        assertEquals("Item deleted", result);
        verify(service, times(1)).getById(orderItemId);
        verify(service, times(1)).deleteItem(orderItemId);
    }

    @Test
    void delete_shouldThrowNoSuchOrderItemException() throws NoSuchOrderItemException {
        int orderItemId = 1;
        when(service.getById(orderItemId)).thenReturn(Optional.empty());

        assertThrows(NoSuchOrderItemException.class, () -> controller.delete(orderItemId));
        verify(service, times(1)).getById(orderItemId);
        verify(service, never()).deleteItem(orderItemId);
    }

    @Test
    void getbyId_shouldReturnOrderItemById() throws NoSuchOrderItemException {
        int itemId = 1;
        OrderItems item = new OrderItems();
        when(service.getById(itemId)).thenReturn(Optional.of(item));

        OrderItems result = controller.getbyId(itemId);

        assertEquals(item, result);
        verify(service, times(2)).getById(itemId);
    }

    @Test
    void getbyId_shouldThrowNoSuchOrderItemException_getbyId() throws NoSuchOrderItemException {
        int itemId = 1;
        when(service.getById(itemId)).thenReturn(Optional.empty());

        assertThrows(NoSuchOrderItemException.class, () -> controller.getbyId(itemId));
        verify(service, times(1)).getById(itemId);
    }
}