package com.inventory.controller;

import com.inventory.entities.Supplier;
import com.inventory.exception.InvalidSupplierException;
import com.inventory.service.SupplierService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class SupplierControllerTest {

    @Mock
    private SupplierService service;

    @InjectMocks
    private SupplierController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void add_shouldAddSupplier() {
        Supplier supplier = new Supplier();
        when(service.add(supplier)).thenReturn(supplier);

        Supplier result = controller.add(supplier);

        assertEquals(supplier, result);
        verify(service, times(1)).add(supplier);
    }

    @Test
    void delete_shouldDeleteSupplier() throws InvalidSupplierException {
        int supplierId = 1;
        when(service.delete(supplierId)).thenReturn("Supplier deleted");

        String result = controller.delete(supplierId);

        assertEquals("Supplier deleted", result);
        verify(service, times(1)).delete(supplierId);
    }

    @Test
    void delete_shouldThrowInvalidSupplierException() throws InvalidSupplierException {
        int supplierId = 1;
        when(service.delete(supplierId)).thenThrow(new InvalidSupplierException("Supplier not found"));

        assertThrows(InvalidSupplierException.class, () -> controller.delete(supplierId));
        verify(service, times(1)).delete(supplierId);
    }

    @Test
    void get_shouldReturnListOfSuppliers() {
        List<Supplier> suppliers = Arrays.asList(new Supplier(), new Supplier());
        when(service.getSuppliers()).thenReturn(suppliers);

        List<Supplier> result = controller.get();

        assertEquals(suppliers, result);
        verify(service, times(1)).getSuppliers();
    }

    @Test
    void getbyid_shouldReturnSupplierById() throws InvalidSupplierException {
        int supplierId = 1;
        Supplier supplier = new Supplier();
        when(service.getBySupplierId(supplierId)).thenReturn(supplier);

        Supplier result = controller.getbyid(supplierId);

        assertEquals(supplier, result);
        verify(service, times(1)).getBySupplierId(supplierId);
    }

    @Test
    void getbyid_shouldThrowInvalidSupplierException_getbyid() throws InvalidSupplierException {
        int supplierId = 1;
        when(service.getBySupplierId(supplierId)).thenThrow(new InvalidSupplierException("Supplier not found"));

        assertThrows(InvalidSupplierException.class, () -> controller.getbyid(supplierId));
        verify(service, times(1)).getBySupplierId(supplierId);
    }
}