package com.inventory.controller;

import com.inventory.entities.Inventory;
import com.inventory.entities.Orders;
import com.inventory.exception.InvalidInventoryDrugException;
import com.inventory.service.FeignToOrders;
import com.inventory.service.InventoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class InventoryControllerTest {

    @Mock
    private InventoryService service;

    @Mock
    private FeignToOrders feign;

    @InjectMocks
    private InventoryController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void view_shouldReturnListOfInventory() {
        List<Inventory> inventories = Arrays.asList(new Inventory(), new Inventory());
        when(service.viewDrugs()).thenReturn(inventories);

        List<Inventory> result = controller.view();

        assertEquals(inventories, result);
        verify(service, times(1)).viewDrugs();
    }

    @Test
    void getbyid_shouldReturnInventoryById() throws InvalidInventoryDrugException {
        int drugId = 1;
        Inventory inventory = new Inventory();
        when(service.getDrugById(drugId)).thenReturn(inventory);

        Inventory result = controller.getbyid(drugId);

        assertEquals(inventory, result);
        verify(service, times(1)).getDrugById(drugId);
    }

    @Test
    void getbyid_shouldThrowInvalidInventoryDrugException() throws InvalidInventoryDrugException {
        int drugId = 1;
        when(service.getDrugById(drugId)).thenThrow(new InvalidInventoryDrugException("Drug not found"));

        assertThrows(InvalidInventoryDrugException.class, () -> controller.getbyid(drugId));
        verify(service, times(1)).getDrugById(drugId);
    }

    @Test
    void add_shouldAddInventory() {
        Inventory inventory = new Inventory();
        when(service.addDrug(inventory)).thenReturn(inventory);

        Inventory result = controller.add(inventory);

        assertEquals(inventory, result);
        verify(service, times(1)).addDrug(inventory);
    }

    @Test
    void edit_shouldEditInventory() {
        Inventory inventory = new Inventory();
        when(service.editDrug(inventory)).thenReturn(inventory);

        Inventory result = controller.edit(inventory);

        assertEquals(inventory, result);
        verify(service, times(1)).editDrug(inventory);
    }

    @Test
    void delete_shouldDeleteInventory() throws InvalidInventoryDrugException {
        int drugId = 1;
        when(service.deleteDrug(drugId)).thenReturn("Drug deleted");

        String result = controller.delete(drugId);

        assertEquals("Drug deleted", result);
        verify(service, times(1)).deleteDrug(drugId);
    }

    @Test
    void delete_shouldThrowInvalidInventoryDrugException_delete() throws InvalidInventoryDrugException {
        int drugId = 1;
        when(service.deleteDrug(drugId)).thenThrow(new InvalidInventoryDrugException("Drug not found"));

        assertThrows(InvalidInventoryDrugException.class, () -> controller.delete(drugId));
        verify(service, times(1)).deleteDrug(drugId);
    }

    @Test
    void getStatus_shouldReturnListOfOrders() {
        List<Orders> orders = Arrays.asList(new Orders(), new Orders());
        when(feign.getOrders()).thenReturn(orders);

        List<Orders> result = controller.getStatus();

        assertEquals(orders, result);
        verify(feign, times(1)).getOrders();
    }

    @Test
    void update_shouldUpdateOrderStatus() {
        int orderId = 1;
        String status = "Shipped";
        Orders order = new Orders();
        when(feign.update(orderId, status)).thenReturn(order);

        Orders result = controller.update(orderId, status);

        assertEquals(order, result);
        verify(feign, times(1)).update(orderId, status);
    }
}