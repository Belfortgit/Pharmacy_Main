package com.inventory;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.inventory.entities.Inventory;
import com.inventory.entities.Supplier;
import com.inventory.exception.InvalidInventoryDrugException;
import com.inventory.exception.InvalidSupplierException;
import com.inventory.service.InventoryService;
import com.inventory.service.SupplierService;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class InventorySupplierPharmacyApplicationTests {

	@Mock
	InventoryService inventory;
	
	@Mock
	SupplierService supplier;
	
	@Test
	void testInventoryforGet() {
		
		Inventory inv = new Inventory(1, "drugName", "description", 12, 23, 1);
		List<Inventory> list = new ArrayList<Inventory>();
		list.add(inv);
		
		when(inventory.viewDrugs()).thenReturn(list);
		assertSame(inventory.viewDrugs(),list);
	}

	@Test
	void testInventoryforAdd() {
		
		Inventory inv = new Inventory(1, "drugName", "description", 12, 23, 1);
		
		when(inventory.addDrug(inv)).thenReturn(inv);
		assertSame(inventory.addDrug(inv),inv);
	}
	
	@Test
	void testInventoryforEdit() {
		
		Inventory inv = new Inventory(1, "drugName", "description", 12, 23, 1);
		
		when(inventory.editDrug(inv)).thenReturn(inv);
		assertSame(inventory.editDrug(inv),inv);
	}
	
	@Test
	void testInventoryforDelete() throws InvalidInventoryDrugException {
		
		when(inventory.deleteDrug(1)).thenReturn("Deleted");
		assertSame(inventory.deleteDrug(1),"Deleted");
	}
	
	@Test
	void testInventoryforDeleteThrowsException() throws InvalidInventoryDrugException {
		
		when(inventory.deleteDrug(12121212)).thenThrow(new InvalidInventoryDrugException(null));
		
		assertThrows(InvalidInventoryDrugException.class, () -> {
			inventory.deleteDrug(12121212);
		});
	}
	
	@Test
	void testSupplierforGet()
	{
		List<Supplier> list = new ArrayList<>();
		Supplier sup = new Supplier(1,"supplierName", (long) 234356456,"address");
		list.add(sup);
		
		when(supplier.getSuppliers()).thenReturn(list);
		assertSame(supplier.getSuppliers(),list);
		
	}
	
	@Test
	void testSupplierforAdd()
	{
		Supplier sup = new Supplier(1,"supplierName", (long) 234356456,"address");
		
		when(supplier.add(sup)).thenReturn(sup);
		assertSame(supplier.add(sup),sup);
		
	}
	
	@Test
	void testSupplierforDelete() throws InvalidSupplierException
	{
		when(supplier.delete(1)).thenReturn("Deleted");
		assertSame(supplier.delete(1),"Deleted");	
	}
	
	@Test
	void testSupplierforDeleteThrowsException() throws InvalidSupplierException
	{
		when(supplier.delete(18989)).thenThrow(InvalidSupplierException.class);
		assertThrows(InvalidSupplierException.class, () -> {
			supplier.delete(18989);
		});
	}
	
	@Test
	void testSupplierforGetById() throws InvalidSupplierException
	{
		Supplier sup = new Supplier(1,"supplierName", (long) 234356456,"address");
		when(supplier.getBySupplierId(1)).thenReturn(sup);
		
		assertSame(supplier.getBySupplierId(1),sup);
	}
	
	@Test
	void testSupplierforGetByIdThrowException() throws InvalidSupplierException
	{
		Supplier sup = new Supplier(1,"supplierName", (long) 234356456,"address");
		when(supplier.getBySupplierId(1909090)).thenThrow(InvalidSupplierException.class);
		assertThrows(InvalidSupplierException.class, () -> {
			supplier.getBySupplierId(1909090);
		});
		
		
	}

}
