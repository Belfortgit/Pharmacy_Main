package com.inventory.exception;

public class InvalidSupplierException extends Exception {
	public InvalidSupplierException(String msg) {
		super(msg);
	}
}
