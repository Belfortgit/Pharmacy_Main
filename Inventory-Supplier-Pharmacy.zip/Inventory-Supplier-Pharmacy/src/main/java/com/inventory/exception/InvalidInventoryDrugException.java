package com.inventory.exception;

public class InvalidInventoryDrugException extends Exception{

	public InvalidInventoryDrugException(String msg)
	{
		super(msg);
	}
}
