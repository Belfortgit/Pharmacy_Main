package com.inventory.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
@EnableWebSecurity
public class SecurityInventoryConfiguration {

	@Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("My Microservice API")
                        .version("v1")
                        .description("This is the API documentation for my microservice"));
    }
	
	@Bean
	public SecurityFilterChain chain(HttpSecurity http) throws Exception
	{
		http.csrf(cust -> cust.disable());
		return http.build();
	}
	
}
