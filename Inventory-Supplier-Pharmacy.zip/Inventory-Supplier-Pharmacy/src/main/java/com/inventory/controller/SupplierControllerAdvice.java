package com.inventory.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.inventory.entities.OrderException;
import com.inventory.exception.InvalidSupplierException;

@RestControllerAdvice
public class SupplierControllerAdvice {

    private Logger logger = LoggerFactory.getLogger(SupplierControllerAdvice.class);

    @ExceptionHandler(InvalidSupplierException.class)
    public ResponseEntity<Object> handle(InvalidSupplierException ie) {
        logger.error("InvalidSupplierException occurred: {}", ie.getMessage());
        OrderException oe = new OrderException(ie.getMessage(), "Try with a differnt or Valid Supplier Id", "InvalidSupplierException");
        return new ResponseEntity<>(oe, HttpStatus.BAD_REQUEST);
    }
}