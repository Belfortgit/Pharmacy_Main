package com.inventory.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inventory.entities.OrderException;
import com.inventory.exception.InvalidInventoryDrugException;

import feign.FeignException;

@RestControllerAdvice
public class InventoryControllerAdvice {

    private Logger logger = LoggerFactory.getLogger(InventoryControllerAdvice.class);

    @ExceptionHandler(FeignException.class)
    public OrderException handle(FeignException e) {
        logger.error("FeignException occurred: {}", e.getMessage());
        String errorBody = e.contentUTF8();
        ObjectMapper mapper = new ObjectMapper();
        try {
            OrderException orderException = mapper.readValue(errorBody, OrderException.class);
            logger.info("Parsed Feign error response: {}", orderException);
            return orderException;
        } catch (IOException ex) {
            logger.error("Error parsing Feign error response: {}", ex.getMessage());
            return new OrderException("Error parsing Feign error response", "Please check the logs", "ParseException");
        }
    }

    @ExceptionHandler(InvalidInventoryDrugException.class)
    public ResponseEntity<Object> handleInventory(InvalidInventoryDrugException ex) {
        logger.error("InvalidInventoryDrugException occurred: {}", ex.getMessage());
        OrderException oe = new OrderException(ex.getMessage(), "Try with a differnt or Valid Drug Id", "InvalidInventoryDrugException");
        return new ResponseEntity<>(oe, HttpStatus.BAD_REQUEST);
    }
}