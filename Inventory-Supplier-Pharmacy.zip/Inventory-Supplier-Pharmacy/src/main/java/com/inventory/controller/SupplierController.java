package com.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inventory.entities.Supplier;
import com.inventory.exception.InvalidSupplierException;
import com.inventory.service.SupplierService;

@RestController
@RequestMapping("/supplier")
public class SupplierController {

	@Autowired
	private SupplierService service;
	
	@PostMapping("/add")
	public Supplier add(@RequestBody Supplier supplier)
	{
		return service.add(supplier);
	}
	
	@DeleteMapping("/delete/{supplierId}")
	public String delete(@PathVariable int supplierId) throws InvalidSupplierException
	{
		return service.delete(supplierId);
	}
	
	@GetMapping("/view")
	public List<Supplier> get()
	{
		return service.getSuppliers();
	}
	
	@GetMapping("/{supplierid}")
	public Supplier getbyid(@PathVariable int supplierid) throws InvalidSupplierException
	{
		return service.getBySupplierId(supplierid);
	}
}
