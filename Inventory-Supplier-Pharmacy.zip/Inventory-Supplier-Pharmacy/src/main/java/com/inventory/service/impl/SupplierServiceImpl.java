package com.inventory.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.entities.Supplier;
import com.inventory.exception.InvalidSupplierException;
import com.inventory.repository.SupplierRepository;
import com.inventory.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService{

    private Logger logger = LoggerFactory.getLogger(SupplierServiceImpl.class);

    @Autowired
    private SupplierRepository repo;
    
    @Override
    public List<Supplier> getSuppliers() {
        logger.info("Fetching all suppliers.");
        List<Supplier> suppliers = repo.findAll();
        logger.info("Retrieved {} suppliers.", suppliers.size());
        return suppliers;
    }

    @Override
    public Supplier add(Supplier supplier) {
        logger.info("Adding supplier: {}", supplier);
        Supplier savedSupplier = repo.save(supplier);
        logger.info("Supplier added successfully with id: {}", savedSupplier.getSupplierId());
        return savedSupplier;
    }

    @Override
    public String delete(int supplierId) throws InvalidSupplierException {
        logger.info("Deleting supplier with id: {}", supplierId);
        Optional<Supplier> obj = repo.findById(supplierId);
        
        if(obj.isPresent())
        {
            repo.deleteById(supplierId);
            logger.info("Supplier with id {} deleted successfully.", supplierId);
            return "Deleted the Supplier of Id ="+supplierId;
        }
        else {
            logger.warn("Supplier with id {} not found, cannot delete.", supplierId);
            throw new InvalidSupplierException("Supplier with id "+supplierId+" is not present");
        }
        
    }

    @Override
    public Supplier getBySupplierId(int supplierid) throws InvalidSupplierException {
        logger.info("Fetching supplier with id: {}", supplierid);
        Optional<Supplier> obj = repo.findById(supplierid);
        
        if(obj.isPresent())
        {
            logger.info("Supplier with id {} found.", supplierid);
            return obj.get();
        }
        else {
            logger.warn("Supplier with id {} not found.", supplierid);
            throw new InvalidSupplierException("Supplier with id "+supplierid+" is not present");
        }
    }

}