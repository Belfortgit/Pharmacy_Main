package com.inventory.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.entities.Inventory;
import com.inventory.exception.InvalidInventoryDrugException;
import com.inventory.repository.InventoryRepository;
import com.inventory.service.InventoryService;

import feign.FeignException;

@Service
public class InventoryServiceImpl implements InventoryService{

    private Logger logger = LoggerFactory.getLogger(InventoryServiceImpl.class);

    @Autowired
    private InventoryRepository repo;
    
    @Override
    public List<Inventory> viewDrugs() {
        logger.info("Fetching all drugs from inventory.");
        List<Inventory> drugs = repo.findAll();
        logger.info("Retrieved {} drugs from inventory.", drugs.size());
        return drugs;
    }

    @Override
    public Inventory addDrug(Inventory inventory) {
        logger.info("Adding drug to inventory: {}", inventory);
        Inventory savedInventory = repo.save(inventory);
        logger.info("Drug added successfully with id: {}", savedInventory.getDrugId());
        return savedInventory;
    }

    @Override
    public Inventory editDrug(Inventory inventory) {
        logger.info("Editing drug in inventory: {}", inventory);
        Inventory updatedInventory = repo.save(inventory);
        logger.info("Drug updated successfully with id: {}", updatedInventory.getDrugId());
        return updatedInventory;
    }

    @Override
    public String deleteDrug(int drugId) throws InvalidInventoryDrugException {
        logger.info("Deleting drug with id: {}", drugId);
        Optional<Inventory> obj = repo.findById(drugId);
        if(obj.isPresent())
        {
            repo.deleteById(drugId);
            logger.info("Drug with id {} deleted successfully.", drugId);
            return "Drug of Id "+drugId+" Deleted.....";
        }
        else {
            logger.warn("Drug with id {} not found, cannot delete.", drugId);
            throw new InvalidInventoryDrugException("There is no such Drug with id "+drugId);
        }
    }

	@Override
	public Inventory getDrugById(int drugId) throws InvalidInventoryDrugException {
		
		logger.info("Getting drug with id: {}", drugId);
		Optional<Inventory> obj = repo.findById(drugId);
		if(obj.isPresent())
        {
            logger.info("Drug with id {} Fetched successfully.", drugId);
            return obj.get();
        }
        else {
            logger.warn("Drug with id {} not found, cannot Fetch.", drugId);
            throw new InvalidInventoryDrugException("There is no such Drug with id "+drugId);
        }
	}

}