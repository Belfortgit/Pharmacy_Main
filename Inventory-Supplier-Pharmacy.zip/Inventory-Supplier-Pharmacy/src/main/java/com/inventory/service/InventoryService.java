package com.inventory.service;

import java.util.List;

import com.inventory.entities.Inventory;
import com.inventory.exception.InvalidInventoryDrugException;
import com.inventory.repository.InventoryRepository;

public interface InventoryService {

	List<Inventory> viewDrugs();
	Inventory getDrugById(int drugId) throws InvalidInventoryDrugException;
	Inventory addDrug(Inventory inventory);
	Inventory editDrug(Inventory inventory);
	String deleteDrug(int drugId) throws InvalidInventoryDrugException;
	
}
