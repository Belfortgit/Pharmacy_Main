package com.inventory.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.inventory.entities.Orders;

//@FeignClient(url="http://localhost:8081", value="OrdersPharmacy")
@FeignClient(name= "ORDERS-PHARMACY")
public interface FeignToOrders {

	@GetMapping("/orders/view")
	List<Orders> getOrders();
	
	@PutMapping("/orders/{orderId}/{status}")
	public Orders update(@PathVariable int orderId, @PathVariable String status);
}
