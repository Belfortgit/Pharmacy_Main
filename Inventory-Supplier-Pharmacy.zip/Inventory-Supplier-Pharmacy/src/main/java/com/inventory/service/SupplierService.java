package com.inventory.service;

import java.util.List;

import com.inventory.entities.Supplier;
import com.inventory.exception.InvalidSupplierException;

public interface SupplierService {
	
	List<Supplier> getSuppliers();
	Supplier getBySupplierId(int supplierid) throws InvalidSupplierException;
	Supplier add(Supplier supplier);
	String delete(int supplierId) throws InvalidSupplierException;
}
