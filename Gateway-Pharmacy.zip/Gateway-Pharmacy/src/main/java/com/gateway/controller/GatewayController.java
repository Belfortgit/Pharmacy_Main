package com.gateway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("gateway")
public class GatewayController {

	@GetMapping("/actuator/info")
	public String get()
	{
		return "<h1>WELCOME TO PHARMACY SERVICES.....</h1><br>" +
	               "<h2> /app/user => User Services  </h2><br>" +
	               " <h2> /appinv/inventory => Inventory Service  </h2><br>" +
	               " <h2> /apporder/order => Order Service  </h2>";
		//return "<h1> Use /register or /login ";
	}
	
	@GetMapping("/sample")
	public String sample()
	{
		return "Hello.................";
	}
	
	
}
