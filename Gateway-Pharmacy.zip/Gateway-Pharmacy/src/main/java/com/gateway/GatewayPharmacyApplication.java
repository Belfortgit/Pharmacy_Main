package com.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayPharmacyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayPharmacyApplication.class, args);
	}

}
